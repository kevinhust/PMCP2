import boto3
import pandas as pd
import os
import json
import time
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Get environment variables
    table_name = os.environ['DYNAMO_TABLE']
    bucket_name = os.environ['S3_BUCKET']
    s3_prefix = os.environ['S3_PREFIX']

    # Delay for 15 seconds to ensure process-stock-data has completed
    time.sleep(15)

    # Process DynamoDB Stream records
    new_records = []
    for record in event['Records']:
        if record['eventName'] in ['INSERT', 'MODIFY']:
            new_image = record['dynamodb']['NewImage']
            # Convert DynamoDB item to a Python dict
            item = {
                'symbol': new_image['stock_symbol']['S'],
                'timestamp': int(new_image['timestamp']['N']),
                'current_price': float(new_image['current_price']['N']),
                'macd': float(new_image['macd']['N']),
                'rsi': float(new_image['rsi']['N']),
                'bb_upper': float(new_image['bb_upper']['N']),
                'bb_lower': float(new_image['bb_lower']['N']),
                'volume': int(new_image['volume']['N'])
            }
            new_records.append(item)

    if not new_records:
        return {
            'statusCode': 200,
            'body': 'No new records to process'
        }

    # Convert new records to DataFrame
    new_df = pd.DataFrame(new_records)

    # Read existing CSV from S3 (if exists)
    s3_key = f"{s3_prefix}/stock_data.csv"
    try:
        # Download existing CSV
        existing_csv = s3.get_object(Bucket=bucket_name, Key=s3_key)
        existing_df = pd.read_csv(existing_csv['Body'])
        # Append new records
        updated_df = pd.concat([existing_df, new_df], ignore_index=True)
    except s3.exceptions.NoSuchKey:
        # If file doesn't exist, use new records as the initial DataFrame
        updated_df = new_df

    # Save updated DataFrame to CSV
    csv_buffer = updated_df.to_csv(index=False)

    # Upload updated CSV to S3
    s3.put_object(Bucket=bucket_name, Key=s3_key, Body=csv_buffer)

    # Update manifest file for QuickSight
    manifest = {
        "fileLocations": [
            {
                "URIs": [
                    f"s3://{bucket_name}/{s3_key}"
                ]
            }
        ]
    }
    s3.put_object(
        Bucket=bucket_name,
        Key=f"{s3_prefix}/stock_data_manifest.json",
        Body=json.dumps(manifest)
    )

    return {
        'statusCode': 200,
        'body': f"Successfully appended {len(new_records)} records to s3://{bucket_name}/{s3_key}"
    }